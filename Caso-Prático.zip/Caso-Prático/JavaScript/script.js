//Caso Prático JavaScript
document.addEventListener("DOMContentLoaded", function () {
    let catalog = [];

    fetch("../JSon/catalog.json")
        .then(response => response.json())
        .then(data => {
            catalog = data.products;
            loadCategories(catalog);
            loadProducts(catalog);
            populateProductSelect(catalog);
        })
        .catch(error => console.error("Erro ao carregar produtos:", error));

    function loadCategories(products) {
        const categorySelect = document.getElementById("category-select");
        categorySelect.innerHTML = "";

        const categories = new Set(["all"]);

        products.forEach(product => {
            if (product.category) {
                categories.add(product.category);
            }
        });

        categories.forEach(category => {
            const option = document.createElement("option");
            option.value = category;
            option.textContent = category === "all" ? "Todas as categorias" : category;
            categorySelect.appendChild(option);
        });
    }

    document.getElementById("category-select").addEventListener("change", function () {
        const selectedCategory = this.value;

        fetch("/JSon/catalog.json")
            .then(response => response.json())
            .then(data => {
                const filteredProducts = selectedCategory === "all"
                    ? data.products
                    : data.products.filter(p => p.category === selectedCategory);

                loadProducts(filteredProducts);
                populateProductSelect(filteredProducts);
            })
            .catch(error => console.error("Erro ao carregar os produtos:", error));
    });

    function loadProducts(products) {
        const productList = document.getElementById("product-list");
        productList.innerHTML = "";

        products.forEach(product => {
            const productElement = document.createElement("div");
            productElement.classList.add("product");

            productElement.innerHTML = `
                <h3>${product.name}</h3>
                <img src="${product.image}" alt="${product.name}">
                <p>${product.description}</p>
                <p><strong>Preço:</strong> €${product.price}</p>
                <button class="details-btn" data-id="${product.id}">Ver Detalhes</button>
            `;

            productList.appendChild(productElement);
        });

        document.querySelectorAll(".details-btn").forEach(button => {
            button.addEventListener("click", function () {
                const productId = this.getAttribute("data-id");
                const selectedProductIndex = products.findIndex(p => p.id == productId);
                showLightbox(selectedProductIndex);
            });
        });
    }

    function populateProductSelect(products) {
        const productSelect = document.getElementById("product-select");
        productSelect.innerHTML = '<option value="">Selecione um produto</option>';

        if (products.length === 0) {
            productSelect.innerHTML += '<option value="">Nenhum produto disponível</option>';
        } else {
            products.forEach(product => {
                const option = document.createElement("option");
                option.value = product.id;
                option.textContent = `${product.name} - €${product.price}`;
                productSelect.appendChild(option);
            });
        }
    }

    document.getElementById('calc-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const productId = document.getElementById('product-select').value;
        const quantity = parseInt(document.getElementById('quantity').value);

        if (!productId || quantity <= 0) {
            alert('Selecione um produto e insira uma quantidade válida.');
            return;
        }

        const product = catalog.find(product => product.id === productId);
        const totalValue = product.price * quantity;

        document.getElementById('total-price').textContent = `Valor Total: €${totalValue.toFixed(2)}`;
    });

    function showLightbox(index) {
        const product = catalog[index];
        const lightbox = document.createElement("div");
        lightbox.id = "lightbox";
        lightbox.innerHTML = `
            <div class="lightbox-content">
                <span class="close-btn">&times;</span>
                <button id="prev-btn" class="nav-btn">&laquo; Anterior</button>
                <button id="next-btn" class="nav-btn">Próximo &raquo;</button>
                <h2>${product.name}</h2>
                <img src="${product.image}" alt="${product.name}">
                <p>${product.description}</p>
                <p><strong>Preço:</strong> €${product.price}</p>
            </div>
        `;
        document.body.appendChild(lightbox);

        const closeBtn = lightbox.querySelector(".close-btn");
        closeBtn.addEventListener("click", function () {
            document.body.removeChild(lightbox);
        });

        const prevBtn = lightbox.querySelector("#prev-btn");
        const nextBtn = lightbox.querySelector("#next-btn");

        prevBtn.addEventListener("click", function () {
            const newIndex = (index - 1 + catalog.length) % catalog.length;
            document.body.removeChild(lightbox);
            showLightbox(newIndex);
        });

        nextBtn.addEventListener("click", function () {
            const newIndex = (index + 1) % catalog.length;
            document.body.removeChild(lightbox);
            showLightbox(newIndex);
        });

        lightbox.addEventListener("click", function (event) {
            if (event.target === lightbox) {
                document.body.removeChild(lightbox); //Fecha lightbox ao clicar fora
            }
        });
    }
});

const inputs = document.querySelectorAll('#register-form input');

inputs.forEach(input => {
    input.addEventListener('input', () => {
        if(input.checkValidity()) {
            input.computedStyleMap.borderColor = 'green';
        } else {
            input.computedStyleMap.borderColor = 'red';
        }
    });
});

$(document).ready(function () {
    $('#register-form').submit(function (event) {
        event.preventDefault();

        let formData = new FormData(this);

        $.ajax({
            url: 'register.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                try {
                    const result = JSON.parse(response);

                    if (result.success) {
                        alert(result.message);
                        window.location.href = 'login.php';
                    } else {
                        $('#error-message').text(result.message);
                    }
                } catch (e) {
                    $('#error-message').text('Erro inesperado do servidor.');
                    console.error('Erro JSON:', e, response);
                }
            },
            error: function () {
                $('#error-message').text('Erro ao processar o registo.');
            }
        });
    });
});
