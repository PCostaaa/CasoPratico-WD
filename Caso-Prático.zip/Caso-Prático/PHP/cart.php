<?php
include '../PHP/DB.php';
session_start();

// Iniciar o carrinho
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Adicionar produto ao carrinho
if (isset($_GET['add'])) {
    $productId = $_GET['add'];

    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId]++;
    } else {
        $_SESSION['cart'][$productId] = 1;
    }

    header('Location: cart.php?add_success=1');
    exit();
}

// Remover produto do carrinho
if (isset($_GET['remove'])) {
    $productId = $_GET['remove'];
    unset($_SESSION['cart'][$productId]);
    header('Location: cart.php?remove_success=1');
    exit();
}

// Atualizar quantidades
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['quantities'] as $productId => $quantity) {
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$productId]);
        } else {
            $_SESSION['cart'][$productId] = (int)$quantity;
        }
    }
    header('Location: cart.php');
    exit();
}

// Buscar produtos do carrinho
$cartProducts = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $query = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
    $cartProducts = $query->fetchAll(PDO::FETCH_ASSOC);

    foreach ($cartProducts as $product) {
        $total += $product['price'] * $_SESSION['cart'][$product['id']];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/style.css">
</head>
<body class="container mt-5">
    <div class="container">
        <h1 class="mb-4">Carrinho</h1>

        <?php if (isset($_GET['add_success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Produto adicionado ao carrinho com sucesso!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['remove_success'])): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                Produto removido do carrinho com sucesso!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
            </div>
        <?php endif; ?>

        <?php if (empty($cartProducts)): ?>
            <div class="alert alert-info">O carrinho está vazio.</div>
        <?php else: ?>
            <form method="post">
                <table class="table table-bordered table-hover text-center align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Produto</th>
                            <th>Preço</th>
                            <th>Quantidade</th>
                            <th>Sub-Total</th>
                            <th>Remover</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cartProducts as $product): ?>
                            <tr>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td>€<?= number_format($product['price'], 2, ',', '.') ?></td>
                                <td>
                                    <input type="number" class="form-control text-center" name="quantities[<?= $product['id'] ?>]" value="<?= $_SESSION['cart'][$product['id']] ?>" min="1">
                                </td>
                                <td>€<?= number_format($product['price'] * $_SESSION['cart'][$product['id']], 2, ',', '.') ?></td>
                                <td>
                                    <a href="?remove=<?= $product['id'] ?>" class="btn btn-danger btn-sm">Remover</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="d-flex justify-content-between align-items-center my-3">
                    <h4>Total: € <?= number_format($total, 2, ',', '.') ?></h4>
                    <button type="submit" class="btn btn-primary">Atualizar Carrinho</button>
                </div>
            </form>

            <div class="text-end">
                <a href="checkout.php" class="btn btn-success">Finalizar Compra</a>
            </div>
        <?php endif; ?>
    </div>

    <!--BOOTSTRAP-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="../JavaScript/script.js"></script>

    <!-- ALERTA AUTOMÁTICO -->
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
          setTimeout(() => {
            alert.classList.remove('show');
            alert.classList.add('hide');
          }, 3000); // 3 segundos
        });
      });
    </script>
</body>
</html>
