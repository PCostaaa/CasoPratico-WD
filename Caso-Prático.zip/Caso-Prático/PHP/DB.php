<?php
    $host = 'localhost';
    $db = 'casopratico';
    $user = 'root';
    $password = '';
    $charset = 'utf8mb4';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $password);
    } catch (PDOException $e) {
        die ("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
?>