<?php
session_start();
include '../PHP/DB.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        echo "<script>alert('Por favor, insira o nome de utilizador e a palavra-passe.'); window.location.href='login.php';</script>";
        exit;
    }

    // Procura o utilizador na base de dados
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Guardar apenas o ID, username e role na sessão (nunca password!)
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        // Redirecionar conforme o tipo de utilizador
        if ($user['role'] === 'admin') {
            header('Location: admin.php');
            exit;
        } else {
            header('Location: profile.php');
            exit;
        }
    } else {
        echo "<script>alert('Nome de utilizador e/ou palavra-passe errados.'); window.location.href='login.php';</script>";
        exit;
    }
}
?>
