<?php
session_start();
include '../PHP/DB.php';

// Verificar se o carrinho existe e não está vazio
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<div class='alert alert-warning text-center'>O carrinho está vazio.</div>";
    exit;
}

// Buscar os produtos do carrinho
$ids = implode(',', array_keys($_SESSION['cart']));
$query = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
$products = $query->fetchAll(PDO::FETCH_ASSOC);

// Guardar a encomenda se o utilizador confirmar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        // Criar nova encomenda
        $stmt = $pdo->prepare("INSERT INTO orders (user_id) VALUES (?)");
        $stmt->execute([$_SESSION['user_id']]);
        $orderId = $pdo->lastInsertId();

        // Adicionar items da encomenda
        $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)");

        foreach ($_SESSION['cart'] as $productId => $quantity) {
            $stmt->execute([$orderId, $productId, $quantity]);
        }

        $pdo->commit();

        // Limpar carrinho
        unset($_SESSION['cart']);

        header('Location: profile.php?message=Compra realizada com sucesso!');
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        echo "<div class='alert alert-danger'>Erro ao processar a encomenda: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
}

// Calcular o total
$total = 0;
foreach ($products as $product) {
    $total += $product['price'] * $_SESSION['cart'][$product['id']];
}
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../CSS/style.css">
</head>
<body class="container mt-5">

    <div class="container text-center">
        <h1 class="mb-4">Checkout</h1>

        <div class="card shadow-sm p-4">
            <h2>Total a pagar: <span class="text-success">€<?= number_format($total, 2, ',', '.') ?></span></h2>

            <form method="post" class="mt-4">
                <button type="submit" class="btn btn-success btn-lg">Confirmar Compra</button>
            </form>

            <div class="mt-3">
                <a href="cart.php" class="btn btn-secondary">Voltar ao Carrinho</a>
            </div>
        </div>
    </div>

    <!--BOOTSTRAP-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!--JQuery-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="../JavaScript/script.js"></script>
</body>
</html>
