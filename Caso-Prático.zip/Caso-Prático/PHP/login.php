<?php
session_start();
include '../PHP/DB.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Login bem sucedido
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role']; // importante guardar o papel também

        if ($user['role'] === 'admin') {
            header('Location: admin.php');
            exit();
        } else {
            header('Location: profile.php');
            exit();
        }
    } else {
        echo "Nome de utilizador ou senha incorretos.";
    }
}
?>


<!DOCTYPE html>
<html lang="pt-PT">
<head>
        <!--META TAGS-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Página principal do rapper Sam the Kid">
        <meta name="keywords" content="Sam the Kid, STK, rapper português, hip-hop Portugal, hip-hop tuga, Samuel Mira, artista de hip-hop, música portuguesa, rap Lisboa, Prtca(mente), letras de músicas portuguesas, beats e samples, Valete, Mind da Gap, Regula, Mundo Segundo, Mechelas, Orelha Negra, história do rap-tuga, produtor de  música, MPC, quarto mágico">
        <meta name="author" content="Pedro Costa">
        <!--TITÚLO DA PÁGINA-->
        <title>Index</title>
        <!--CSS/FONTAWESOME/BOOSTRAP-->
        <link rel="stylesheet" href="../CSS/style.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
    <!--Header-->
    <header>
        <nav class="navbar navbar-expand-lg text-light py-3">
            <div class="container-fluid">
              <a class="navbar-brand" href="#"><img src="../Imagens/logo_tvchelas.png" alt="Logo" height="55"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="Index.php" target="_self">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Albuns.php" target="_blank">Álbuns</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Tour.php" target="_blank">Tour</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Contactos.php" target="_blank">Contactos</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Loja.php" target="_blank">Loja <i class="fa-solid fa-shop"></i></a>
                </li>
                <li class="nav-item" id="session">
                  <a class="nav-link" href="login.php">Login<a> 
                </li>
                </ul>
              </div>
            </div>
          </nav>
      </header>

      <main>
        <!--Caroussel Introdutório-->
      <div id="carouselExample" class="carousel slide">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="../Imagens/STK-FOTO-CAR-1.jpg" class="d-block w-100 stk-1" alt="stk-car-1">
          </div>
          <div class="carousel-item">
            <img src="../Imagens/stk-foto-car-2.jpg" class="d-block w-100 stk-2" alt="stk-car-2">
          </div>
          <div class="carousel-item">
            <img src="../Imagens/STK-FOTO-CAR-3.JPG" class="d-block w-100 stk-3" alt="stk-car-3">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      </main>

    <!-- Formulário de Login -->
    <div class="form-container">
        <div class="form-box" id="login-form">
          <form action="login.php" method="post">
            <h2>Login</h2>
            <hr>
            <input type="text" name="username" placeholder="Nome" required>

            <input type="password" name="password" placeholder="Password" required>


            <button type="submit" name="login">Entrar</button>
            <p class="login-link">Ainda não tens conta? <a href="register.php">Registar</a> </p>
          </form>
        </div>
      </div>

      <!--Outras secções-->
      <div class="container mt-4 sections">
      <!--Tour-->
      <div class="row sections-cards">
        <div class="card" id="tour" style="width: 18rem;">
          <img src="../Imagens/stk-card-tour.jpg" class="card-img-top" alt="foto-tour">
          <div class="card-body">
            <h5 class="card-title">Tour</h5>
            <p class="card-text">Fica a conhecer as datas dos próximos concertos.</p>
            <a href="Tour.html" class="btn btn-primary" target="_blank">Próximas datas</a>
          </div>
        </div>
  
        <!--Álbuns-->
        <div class="card" id="albuns" style="width: 18rem;">
          <img src="../Imagens/stk-card-albuns.jpg" class="card-img-top" alt="foto-albuns">
          <div class="card-body">
            <h5 class="card-title">Álbuns</h5>
            <p class="card-text">Conhece o meu trabalho.</p>
            <a href="Albuns.html" class="btn btn-primary" target="_blank">Discografia</a>
          </div>
        </div>
  
        <!--Form Contacto-->
        <div class="card" id="contactos" style="width: 18rem;">
          <img src="../Imagens/stk-card-contactos.jpg" class="card-img-top" alt="foto-contactos">
          <div class="card-body">
            <h5 class="card-title">Conctactos</h5>
            <p class="card-text">Tens alguma dúvida? Fala comigo.</p>
            <a href="Contactos.html" class="btn btn-primary" target="_blank">Contacta-me</a>
          </div>
        </div>
      </div>
      </div><br><br>
      <!--FOOTER-->
    <footer class="bg-dark text-light py-3">
      <div class="container-footer text-center">
          <p>&copy; Sam The Kid | TV Chelas | <a href="#" class="text-light">Política de Privacidade</a></p>
          <div class="mt-3">
              <a href="https://www.tvchelas.com" class="text-light mx-2" aria-label="TvChelas"><i class="fa-solid fa-globe"></i></a>
              <a href="https://www.facebook.com/SamTheKid" class="text-light mx-2" aria-label="LinkedIn"><i class="fab fa-facebook"></i></a>
              <a href="https://www.instagram.com/mechelas" class="text-light mx-2" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
              <a href="https://www.youtube.com/TvChelas" class="text-light mx-2" aria-label="Youtube"><i class="fab fa-youtube fa-youtube"></i></a>
          </div>
      </div>

      
   </footer>
        <!--BOOTSTRAP-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

        <script src="../JavaScript/script.js"></script>
    </body>
</html>