<!DOCTYPE html>
<html lang="pt-PT">
    <head>
        <!--META TAGS-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Página principal do rapper Sam the Kid">
        <meta name="keywords" content="Sam the Kid, STK, rapper português, hip-hop Portugal, hip-hop tuga, Samuel Mira, artista de hip-hop, música portuguesa, rap Lisboa, Prtca(mente), letras de músicas portuguesas, beats e samples, Valete, Mind da Gap, Regula, Mundo Segundo, Mechelas, Orelha Negra, história do rap-tuga, produtor de  música, MPC, quarto mágico">
        <meta name="author" content="Pedro Costa">
        <!--TITÚLO DA PÁGINA-->
        <title>Index</title>
        <!--CSS/FONTAWESOME/BOOSTRAP-->
        <link rel="stylesheet" href="../CSS/style.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
      <!--Header-->
      <header>
        <nav class="navbar navbar-expand-lg text-light py-3">
            <div class="container-fluid">
              <a class="navbar-brand" href="#"><img src="../Imagens/logo_tvchelas.png" alt="Logo" id="logo" height="55"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="Index.php" target="_self">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Albuns.php" target="_blank">Álbuns</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Tour.php" target="_blank">Tour</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Contactos.php" target="_blank">Contactos</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Loja.php" target="_blank">Loja <i class="fa-solid fa-shop"></i></a>
                </li>
                <li class="nav-item" id="session">
                  <a class="nav-link" href="login.php">Login<a> 
                </li>
                </ul>
              </div>
            </div>
          </nav>
      </header>
    <main>
      <!--Caroussel Introdutório-->
      <div id="carouselExample" class="carousel slide">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="../Imagens/STK-FOTO-CAR-1.jpg" class="d-block w-100 stk-1" alt="stk-car-1">
          </div>
          <div class="carousel-item">
            <img src="../Imagens/stk-foto-car-2.jpg" class="d-block w-100 stk-2" alt="stk-car-2">
          </div>
          <div class="carousel-item">
            <img src="../Imagens/STK-FOTO-CAR-3.JPG" class="d-block w-100 stk-3" alt="stk-car-3">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      <!--Accordion-->
      <div class="container mt-4">
        <div class="accordion custom-accordion" id="accordionExample">
          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                <h5>Artista</h5>
              </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body" id="Sobre">
                <span><strong>Sam the Kid</strong>, nome artístico de Samuel Mira, é um rapper e produtor português. Desde os anos 90 no ativo é, para muitos, o melhor rapper português. Com uma carreira de duas décadas, <strong>Sam the Kid</strong> continua a ser uma referência para muitos artistas nacionais, tanto a nível liríco como instrumental (produção musical).
                </span>
                <hr>
                <div class="row cards">
                  <!--Card 1-->
                  <div class="card artista col-4" style="width: 18rem;">
                    <img src="../Imagens/STK-1.png" class="card-img-top" alt="foto-card-1">
                    <div class="card-body artista">
                      <h6 class="card-title">Quarto Mágico</h6>
                      <p class="card-text"><strong>Sam the Kid</strong> no seu quarto, o <em>Quarto Mágico</em>, onde começou a sua carreira.</p>
                    </div>
                  </div>
                  <!--Card 2-->
                  <div class="card artista col-4" style="width: 18rem;">
                    <img src="../Imagens/STK-2.jpg" class="card-img-top" alt="foto-card-2">
                    <div class="card-body artista">
                      <h6 class="card-title">Covil do Dragão</h6>
                      <p class="card-text"><strong>Sam the Kid</strong> no <em>Covil do Dragão</em>, estúdio de Fred Ferreira.</p>
                    </div>
                  </div>
                  <!--Card 3-->
                  <div class="card artista col-4" style="width: 18rem;">
                    <img src="../Imagens/STK-3.jpg" class="card-img-top" alt="foto-card-3">
                    <div class="card-body artista">
                      <h6 class="card-title">Sangue @ Coliseu do Porto</h6>
                      <p class="card-text"><strong>Sam the Kid</strong> a interpretar a faixa <em>Sangue</em>, ao vivo no Coliseu do Porto.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                <h5>Carreira</h5>
              </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <p><strong>Sam the Kid</strong>, lança o seu primeiro álbum, <strong><em>Entre(tanto)</em></strong> em 1999, abrindo portas para uma carreira com mais de 20 anos, pois já desde 1995 que anda "no ativo" no hip-hop nacional.</p>
                <p>Em 2002 lança <strong><em>Sobre(tudo)</em></strong>,o seu segundo álbum de estúdio, acimentando ainda mais o seu estatuto de rapper/produtor. No mesmo ano lança também <em>Beats Vol 1: Amor</em>, um álbum exclusivamente de instrumentais, conceitual e baseado na história de amor dos pais. Em 2008, é reeditado <em>Sobre(tudo)</em>.</p>
                <p>Em 2006 "manda para as ruas" <strong><em>Pratica(mente)</em></strong>, considerado por muitos até hoje, o melhor álbum de hip-hop português.</p>
                <p>Desde aí, <strong>Sam the Kid</strong> tem-se dedicado a participar em outros projetos de hip-hop nacional, fazendo também reedição de <em>Pratica(mente)</em> em 2008.</p>
                <hr>
                <div class="cards row">
                  <!--Entre(tanto)-->
                <div class="card" style="width: 18rem;">
                  <img src="../Imagens/Entre(tanto).jpg" class="card-img-top" alt="album-1">
                  <div class="card-body">
                    <h5 class="card-title">Entre(tanto)</h5>
                  </div>
                </div>
                <!--Sobre(tudo)-->
                <div class="card" style="width: 18rem;">
                  <img src="../Imagens/Sobre(tudo).jpg" class="card-img-top" alt="album-2">
                  <div class="card-body">
                    <h5 class="card-title">Sobre(tudo)</h5>
                  </div>
                </div>
                <!--Beats bol 1: Amor-->
                <div class="card" style="width: 18rem;">
                  <img src="../Imagens/Beats-Vol-1.jpg" class="card-img-top" alt="beat-tape-1">
                  <div class="card-body">
                    <h5 class="card-title">Beats Vol 1: Amor</h5>
                  </div>
                </div>
                <!--Pratica(mente)-->
                <div class="card" style="width: 18rem;">
                  <img src="../Imagens/Pratica(mente).jpg" class="card-img-top" alt="album-3">
                  <div class="card-body">
                    <h5 class="card-title">Pratica(mente)</h5>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                <h5>Outro</h5>
              </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                  <p>Em 2016 <strong>Sam the Kid</strong> cria o canal de youtube <em>Tv Chelas</em>, uma plataforma repleta de arquivos do próprio, podcasts com várias pessoas ligadas ao movimento hip-hop nacional, desde rappers, produtores, DJ's, B-Boys, Taggers, realizadores/fotógrafos e colecionadores.</p>
                  <p>Existe também <a href="https://www.tvchelas.com" id="tvchelas">tvchelas.com</a>, uma loja online de merchandising do próprio, e também de álbuns/projetos em que participou.</p>
              </div>
            </div>
          </div>
        </div>
        <hr>
      </div>

      <!--Outras secções-->
      <div class="container mt-4 sections">
      <!--Tour-->
      <div class="row sections-cards">
        <div class="card" id="tour" style="width: 18rem;">
          <img src="../Imagens/stk-card-tour.jpg" class="card-img-top" alt="foto-tour">
          <div class="card-body">
            <h5 class="card-title">Tour</h5>
            <p class="card-text">Fica a conhecer as datas dos próximos concertos.</p>
            <a href="Tour.php" class="btn btn-primary" target="_blank">Próximas datas</a>
          </div>
        </div>
  
        <!--Álbuns-->
        <div class="card" id="albuns" style="width: 18rem;">
          <img src="../Imagens/stk-card-albuns.jpg" class="card-img-top" alt="foto-albuns">
          <div class="card-body">
            <h5 class="card-title">Álbuns</h5>
            <p class="card-text">Conhece o meu trabalho.</p>
            <a href="Albuns.php" class="btn btn-primary" target="_blank">Discografia</a>
          </div>
        </div>
  
        <!--Form Contacto-->
        <div class="card" id="contactos" style="width: 18rem;">
          <img src="../Imagens/stk-card-contactos.jpg" class="card-img-top" alt="foto-contactos">
          <div class="card-body">
            <h5 class="card-title">Conctactos</h5>
            <p class="card-text">Tens alguma dúvida? Fala comigo.</p>
            <a href="Contactos.php" class="btn btn-primary" target="_blank">Contacta-me</a>
          </div>
        </div>
      </div>
      </div>
    </main>

    <!--FOOTER-->
    <footer class="bg-dark text-light py-3">
      <div class="container-footer text-center">
          <p>&copy; Sam The Kid | TV Chelas | <a href="#" class="text-light">Política de Privacidade</a></p>
          <div class="mt-3">
              <a href="https://www.tvchelas.com" class="text-light mx-2" aria-label="TvChelas"><i class="fa-solid fa-globe"></i></a>
              <a href="https://www.facebook.com/SamTheKid" class="text-light mx-2" aria-label="LinkedIn"><i class="fab fa-facebook"></i></a>
              <a href="https://www.instagram.com/mechelas" class="text-light mx-2" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
              <a href="https://www.youtube.com/TvChelas" class="text-light mx-2" aria-label="Youtube"><i class="fab fa-youtube fa-youtube"></i></a>
          </div>
      </div>
   </footer>
        <!--BOOTSTRAP-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

        <script src="../JavaScript/script.js"></script>
  </body>
</html>
