<!DOCTYPE html>
<html>
    <head>
        <!--META TAGS-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Página de álbuns de Sam the Kid">
        <meta name="keywords" content="Sam the Kid, STK, rapper português, hip-hop Portugal, hip-hop tuga, Samuel Mira, artista de hip-hop, música portuguesa, rap Lisboa, Prtca(mente), letras de músicas portuguesas, beats e samples, Valete, Mind da Gap, Regula, Mundo Segundo, Mechelas, Orelha Negra, história do rap-tuga, produtor de  música, MPC, quarto mágico, concertos de hip-hop, tour">
        <meta name="author" content="Pedro Costa">
        <!--TITÚLO DA PÁGINA-->
        <title>Álbuns</title>
        <!--CSS/FONTAWESOME/BOOSTRAP-->
        <link rel="stylesheet" href="../CSS/style.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
        <!--Header-->
      <header>
        <nav class="navbar navbar-expand-lg text-light py-3">
            <div class="container-fluid">
              <a class="navbar-brand" href="#"><img src="../Imagens/logo_tvchelas.png" alt="Logo" height="55"></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="Index.php" target="_self">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Albuns.php" target="_blank">Álbuns</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Tour.php" target="_blank">Tour</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="Contactos.php" target="_blank">Contactos</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Loja.php" target="_blank">Loja <i class="fa-solid fa-shop"></i></a>
                </li>
                <li class="nav-item" id="session">
                  <a class="nav-link" href="login.php">Login<a> 
                </li>
                </ul>
              </div>
            </div>
          </nav>
      </header>

    <main>
        <!--Caroussel Introdutório-->
        <div id="carouselExample" class="carousel slide">
            <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="../Imagens/STK-FOTO-CAR-1.jpg" class="d-block w-100 stk-1" alt="stk-car-1">
            </div>
            <div class="carousel-item">
                <img src="../Imagens/stk-foto-car-2.jpg" class="d-block w-100 stk-2" alt="stk-car-2">
            </div>
            <div class="carousel-item">
                <img src="../Imagens/STK-FOTO-CAR-3.JPG" class="d-block w-100 stk-3" alt="stk-car-3">
            </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
            </button>
      </div>

      <!--Álbuns-->
      <div class="container mt-4">
        <div class="accordion custom-accordion" id="accordionExample">
          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                <h5>Álbuns</h5>
              </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <div class="container mt-4 albuns-projetos">
                  <div class="card border-secondary" style="width: 18rem;">
                      <img src="../Imagens/Entre(tanto).jpg" class="card-img-top" alt="album-1">
                      <div class="card-body">
                        <h5 class="card-title">Entre(tanto)</h5>
                        <p class="card-text">Primeiro álbum de originais, lançado em 1999.</p>
                        <a href="#" class="btn btn-primary">Esgotado</a>
                      </div>
                    </div>
                
                    <div class="card border-secondary" style="width: 18rem;">
                      <img src="../Imagens/Sobre(tudo).jpg" class="card-img-top" alt="album-2">
                      <div class="card-body">
                        <h5 class="card-title">Sobre(tudo)</h5>
                        <p class="card-text">Segundo álbum de  originais, lançado em 2002.</p>
                        <a href="#" class="btn btn-primary">Esgotado</a>
                      </div>
                    </div>
                
                    
                
                    <div class="card border-secondary" style="width: 18rem;">
                      <img src="../Imagens/Pratica(mente).jpg" class="card-img-top" alt="album-3">
                      <div class="card-body">
                        <h5 class="card-title">Pratica(mente)</h5>
                        <p class="card-text">Terceiro álbum de  originais, lançado em 2006.</p>
                        <a href="https://loja.tvchelas.com/produto/cd-praticamente/" class="btn btn-primary" target="_blank">Compra aqui</a>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>

          <!--Projetos-->
          <div class="accordion-item custom-accordion">
            <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                <h5>Projetos</h5>
              </button>
            </h2>
            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body albuns-projetos">

                <div class="card border-secondary" style="width: 18rem;">
                  <img src="../Imagens/Orelha-Negra-2012.jpg" class="card-img-top" alt="orelha-negra-2012">
                  <div class="card-body">
                    <h5 class="card-title">Orelha Negra</h5>
                    <p class="card-text">Projeto exclusivamente de intrumentais (músicas sem letra), desde 2009.</p>
                    <a href="#" class="btn btn-primary" target="_blank">Esgotado</a>
                  </div>
                </div>

                <div class="card border-secondary" style="width: 18rem;">
                  <img src="../Imagens/5-30.jpg" class="card-img-top" alt="cinco-trinta">
                  <div class="card-body">
                    <h5 class="card-title">5-30</h5>
                    <p class="card-text">Projeto iniciado em 2014, com <strong>Sam the Kid</strong>, <strong>Regula</strong> e <strong>Carlão</strong>(Da Weasel).</p>
                    <a href="#" class="btn btn-primary" target="_blank">Esgotado</a>
                  </div>
                </div>

                <div class="card border-secondary" style="width: 18rem;">
                  <img src="../Imagens/classe-crua.jpg" class="card-img-top" alt="Classe-crua">
                  <div class="card-body">
                    <h5 class="card-title">Classe Crua</h5>
                    <p class="card-text">Projeto criado com o rapper de Odivelas, <strong>Beware Jack</strong>, produzido por Sam the Kid e com letras de Beware. Lançado em 2019. </p>
                    <a href="https://loja.tvchelas.com/produto/cd-classe-crua/" class="btn btn-primary" target="_blank">Compra aqui</a>
                  </div>
                </div>

                <div class="card" style="width: 18rem;">
                  <img src="../Imagens/vludo.jpg" class="card-img-top" alt="Vludo">
                  <div class="card-body">
                    <h5 class="card-title">Vludo</h5>
                    <p class="card-text">Em 2023,em parceria com o rapper de Almada, <strong>Blasph</strong>, <em>Vludo</em> lança <strong>Dedos Finos</strong>, com produção de Sam the Kid e letras  de Blapsh.</p>
                    <a href="https://loja.tvchelas.com/produto/cd-vludo-dedos-finos/" class="btn btn-primary" target="_blank">Compra aqui</a>
                  </div>
                </div>
              </div>  
            </div>
          </div>

          <!--Beat Tapes-->
          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                <h5>Beat Tapes</h5>
              </button>
            </h2>
            <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body albuns-projetos">
                <div class="card border-secondary" style="width: 18rem;">
                  <img src="../Imagens/Beats-Vol-1.jpg" class="card-img-top" alt="beat-tape-1">
                  <div class="card-body">
                    <h5 class="card-title">Beats Vol 1: Amor</h5>
                    <p class="card-text">Primeira Beat tape, em "homenagem" à história de amor dos pais. Lançada em 2002.</p>
                    <a href="#" class="btn btn-primary">Esgotado</a>
                  </div>
                </div>

                <div class="card border-secondary" style="width: 18rem;">
                  <img src="../Imagens/caixa-de-ritmos.jpg" class="card-img-top" alt="beat-tape-2">
                  <div class="card-body">
                    <h5 class="card-title">Caixa de Ritmos</h5>
                    <p class="card-text">Lançada em 2020, esta é a segunda <em>Beat Tape</em> de Sam the Kid.</p>
                    <a href="https://loja.tvchelas.com/produto/cd-caixa-de-ritmos/" class="btn btn-primary" target="_blank">Compra aqui</a>
                  </div>
                </div>
        
                <div class="card" style="width: 18rem;">
                  <img src="../Imagens/caixa-de-ritmos-2.jpg" class="card-img-top" alt="beat-tape-3">
                  <div class="card-body">
                    <h5 class="card-title">Caixa  de Ritmos 2</h5>
                    <p class="card-text">Terceira <em>Beat Tape</em>, lançada em 2022.</p>
                    <a href="https://loja.tvchelas.com/produto/cd-caixa-de-ritmos-2/" class="btn btn-primary" target="_blank">Compra aqui</a>
                  </div>
                </div>

                <div class="card border-secondary" style="width: 18rem;">
                  <img src="../Imagens/quarto-magico.jpg" class="card-img-top" alt="beat-tape-4">
                  <div class="card-body">
                    <h5 class="card-title">Quarto Mágico</h5>
                    <p class="card-text">Quarta Beat Tape de Sam the Kid, lançada em 2023.</p>
                    <a href="https://loja.tvchelas.com/produto/cd-quarto-magico/" class="btn btn-primary" target="_blank">Compra aqui</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!--Outras secções-->
      <div class="container mt-4 sections">
        <!--Tour-->
        <div class="row sections-cards">
          <div class="card border-dark" id="tour" style="width: 18rem;">
            <img src="../Imagens/stk-card-tour.jpg" class="card-img-top" alt="foto-tour">
            <div class="card-body">
              <h5 class="card-title">Tour</h5>
              <p class="card-text">Fica a conhecer as datas dos próximos concertos.</p>
              <a href="Tour.php" class="btn btn-primary" target="_blank">Próximas datas</a>
            </div>
          </div>
    
          <!--Álbuns-->
          <div class="card border-dark" id="albuns" style="width: 18rem;">
            <img src="../Imagens/stk-card-albuns.jpg" class="card-img-top" alt="foto-albuns">
            <div class="card-body">
              <h5 class="card-title">Álbuns</h5>
              <p class="card-text">Conhece o meu trabalho.</p>
              <a href="Albuns.php" class="btn btn-primary" target="_blank">Discografia</a>
            </div>
          </div>
    
          <!--Form Contacto-->
          <div class="card border-dark" id="contactos" style="width: 18rem;">
            <img src="../Imagens/stk-card-contactos.jpg" class="card-img-top" alt="foto-contactos">
            <div class="card-body">
              <h5 class="card-title">Conctactos</h5>
              <p class="card-text">Tens alguma dúvida? Fala comigo.</p>
              <a href="Contactos.html" class="btn btn-primary" target="_blank">Contacta-me</a>
            </div>
          </div>
        </div>
        </div>
    </main>

      <!--FOOTER-->
    <footer class="bg-dark text-light py-3">
        <div class="container-footer text-center">
            <p>&copy; Sam The Kid | TV Chelas | <a href="#" class="text-light">Política de Privacidade</a></p>
            <div class="mt-3">
                <a href="https://www.tvchelas.com" class="text-light mx-2" aria-label="TvChelas"><i class="fa-solid fa-globe"></i></a>
                <a href="https://www.facebook.com/SamTheKid" class="text-light mx-2" aria-label="LinkedIn"><i class="fab fa-facebook"></i></a>
                <a href="https://www.instagram.com/mechelas" class="text-light mx-2" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="https://www.youtube.com/TvChelas" class="text-light mx-2" aria-label="Youtube"><i class="fab fa-youtube fa-youtube"></i></a>
            </div>
        </div>
      </footer>
          <!--BOOTSTRAP-->
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>

