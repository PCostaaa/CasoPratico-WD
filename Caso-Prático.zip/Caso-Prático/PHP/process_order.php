<?php
session_start();
include '../PHP/DB.php';

// Verifica se é admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

if (isset($_GET['id'])) {
    $orderId = $_GET['id'];

    // Atualiza status da encomenda para completed
    $stmt = $pdo->prepare("UPDATE orders SET status = 'completed' WHERE id = ?");
    $stmt->execute([$orderId]);
}

header('Location: admin.php');
exit();
?>
