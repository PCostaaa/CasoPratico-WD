<!DOCTYPE html>
<html>
    <head>
        <!--META TAGS-->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Página de contacto de Sam the Kid, envie a sua mensagem para falar com ele.">
        <meta name="keywords" content="Sam the Kid, STK, rapper português, hip-hop Portugal, hip-hop tuga, Samuel Mira, artista de hip-hop, música portuguesa, rap Lisboa, Prtca(mente), letras de músicas portuguesas, beats e samples, Valete, Mind da Gap, Regula, Mundo Segundo, Mechelas, Orelha Negra, história do rap-tuga, produtor de  música, MPC, quarto mágico, concertos de hip-hop, tour">
        <meta name="author" content="Pedro Costa">
        <!--TITÚLO DA PÁGINA-->
        <title>Contactos</title>
        <!--CSS/FONTAWESOME/BOOSTRAP-->
        <link rel="stylesheet" href="../CSS/style.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

        <script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    
    form.addEventListener('submit', function (event) {
        event.preventDefault(); // Impede envio automático

        // Obtém os valores dos campos
        const firstName = document.getElementById('firstName').value.trim();
        const lastName = document.getElementById('lastName').value.trim();
        const email = document.getElementById('emailInfo').value.trim();
        const phone = document.getElementById('phoneNumber').value.trim();
        const comments = document.getElementById('comments').value.trim();

        // Expressões regulares para validação de email e de  telefone
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneRegex = /^[\d\s+\-()]{9,15}$/;

        // Validação campos
        if (firstName === '' || lastName === '' || email === '' || comments === '') {
            alert('Por favor preencha todos os campos obrigatórios.');
            return;
        }

        if (!emailRegex.test(email)) {
            alert('Por favor insira um email válido.');
            return;
        }

        if (phone !== '' && !phoneRegex.test(phone)) {
            alert('Por favor insira um número de telefone válido.');
            return;
        }

        // Se passou todas as validações
        alert('Mensagem enviada com sucesso!');
        form.reset(); // Limpa o formulário
    });
});
</script>

    </head>

    <body>
        <!--Header-->
        <header>
            <nav class="navbar navbar-expand-lg text-light py-3">
                <div class="container-fluid">
                  <a class="navbar-brand" href="#"><img src="../Imagens/logo_tvchelas.png" alt="Logo" height="55"></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="Index.php" target="_self">Home</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="Albuns.php" target="_blank">Álbuns</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="Tour.php" target="_blank">Tour</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="Contactos.php" target="_blank">Contactos</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="Loja.php" target="_blank">Loja <i class="fa-solid fa-shop"></i></a>
                      </li>
                      <li class="nav-item" id="session">
                        <a class="nav-link" href="login.php">Login<a> 
                      </li>
                    </ul>
                  </div>                
                </div>
              </nav>
          </header>

          <main>
            <!--Caroussel Introdutório-->
            <div id="carouselExample" class="carousel slide">
                <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="../Imagens/STK-FOTO-CAR-1.jpg" class="d-block w-100 stk-1" alt="stk-car-1">
                </div>
                <div class="carousel-item">
                    <img src="../Imagens/stk-foto-car-2.jpg" class="d-block w-100 stk-2" alt="stk-car-2">
                </div>
                <div class="carousel-item">
                    <img src="../Imagens/STK-FOTO-CAR-3.JPG" class="d-block w-100 stk-3" alt="stk-car-3">
                </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
                </button>
            </div>

            <!--Form Contacto-->
            <div class="container mt-5">
                <h2>Contacta-me</h2>
                <form class="row g-3">
                    <div class="col-md-6">
                        <label for="firstName" class="form-label">Primeiro Nome</label>
                        <input type="text" class="form-control" id="firstName" required> 
                    </div>
                    <div class="col-md-6">
                        <label for="lastName" class="form-label">Último Nome</label>
                        <input type="text" class="form-control" id="lastName" required>
                    </div>
                    <div class="col-md-8">
                        <label for="emailInfo" class="form-label">E-mail</label>
                        <input type="email" class="form-control" id="emailInfo" required>
                    </div>
                    <div class="col-md-4">
                        <label for="phoneNumber" class="form-label">Telefone</label>
                        <input type="text" class="form-control" id="phoneNumber" placeholder="+351 *** *** ***">
                    </div>
                    <div class="col-md-12">
                        <label for="comments" class="form-label">Escreve a tua mensagem.</label>
                        <textarea class="form-control" id="comments" rows="3" required></textarea>
                    </div>
                    <div class="col-md-12">
                        <button type="submit"class="btn btn-primary">Enviar</button>
                    </div>
                </form>
            </div>

            <!--Outras secções-->
      <div class="container mt-4 sections">
        <!--Tour-->
        <div class="row sections-cards">
          <div class="card" id="tour" style="width: 18rem;">
            <img src="../Imagens/stk-card-tour.jpg" class="card-img-top" alt="foto-tour">
            <div class="card-body">
              <h5 class="card-title">Tour</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="Tour.php" class="btn btn-primary" target="_blank">Próximas datas</a>
            </div>
          </div>
    
          <!--Álbuns-->
          <div class="card" id="albuns" style="width: 18rem;">
            <img src="../Imagens/stk-card-albuns.jpg" class="card-img-top" alt="foto-albuns">
            <div class="card-body">
              <h5 class="card-title">Álbuns</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="Albuns.php" class="btn btn-primary" target="_blank">Discografia</a>
            </div>
          </div>
    
          <!--Form Contacto-->
          <div class="card" id="contactos" style="width: 18rem;">
            <img src="../Imagens/stk-card-contactos.jpg" class="card-img-top" alt="foto-contactos">
            <div class="card-body">
              <h5 class="card-title">Conctactos</h5>
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <a href="Contactos.php" class="btn btn-primary" target="_blank">Contacta-me</a>
            </div>
          </div>
        </div>
        </div>
          </main>

          <!--FOOTER-->
          <footer class="bg-dark text-light py-3">
                <div class="container-footer text-center">
                    <p>&copy; Sam The Kid | TV Chelas | <a href="#" class="text-light">Política de Privacidade</a></p>
                    <div class="mt-3">
                        <a href="https://www.tvchelas.com" class="text-light mx-2" aria-label="TvChelas"><i class="fa-solid fa-globe"></i></a>
                        <a href="https://www.facebook.com/SamTheKid" class="text-light mx-2" aria-label="LinkedIn"><i class="fab fa-facebook"></i></a>
                        <a href="https://www.instagram.com/mechelas" class="text-light mx-2" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.youtube.com/TvChelas" class="text-light mx-2" aria-label="Youtube"><i class="fab fa-youtube fa-youtube"></i></a>
                    </div>
                </div>
          </footer>
            <!--BOOTSTRAP-->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>