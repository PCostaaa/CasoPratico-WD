<?php
include '../PHP/DB.php';
session_start();

// Redireciona se não estiver logado
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Procura utilizador na base de dados
$username = $_SESSION['username'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Caso o utilizador não seja encontrado
if (!$user) {
    echo "Erro: Utilizador não encontrado.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Sam the Kid, STK, rapper português, hip-hop Portugal, hip-hop tuga, Samuel Mira, artista de hip-hop, música portuguesa, rap Lisboa">
    <meta name="author" content="Pedro Costa">
    <title>USER PAGE</title>

    <link rel="stylesheet" href="../CSS/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg text-light py-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><img src="../Imagens/logo_tvchelas.png" alt="Logo" height="55"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link active" href="Index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="Albuns.php" target="_blank">Álbuns</a></li>
                    <li class="nav-item"><a class="nav-link" href="Tour.php" target="_blank">Tour</a></li>
                    <li class="nav-item"><a class="nav-link" href="Contactos.php" target="_blank">Contactos</a></li>
                    <li class="nav-item"><a class="nav-link" href="Loja.php" target="_blank">Loja <i class="fa-solid fa-shop"></i></a></li>
                    <li class="nav-item"><a class="nav-link" href="index.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<main class="container mt-4">
    <h1 class="mb-4">O meu Perfil</h1>

    <div class="mb-5 perfil">
        <p><strong>Nome de Utilizador:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
    </div>
</main>

<section class="container mt-5">
    <!--Outras secções-->
    <div class="row">
        <div class="card me-3" style="width: 18rem;">
            <img src="../Imagens/stk-card-tour.jpg" class="card-img-top" alt="foto-tour">
            <div class="card-body">
                <h5 class="card-title">Tour</h5>
                <p class="card-text">Fica a conhecer as datas dos próximos concertos.</p>
                <a href="Tour.php" class="btn btn-primary" target="_blank">Próximas datas</a>
            </div>
        </div>

        <div class="card me-3" style="width: 18rem;">
            <img src="../Imagens/stk-card-albuns.jpg" class="card-img-top" alt="foto-albuns">
            <div class="card-body">
                <h5 class="card-title">Álbuns</h5>
                <p class="card-text">Conhece o meu trabalho.</p>
                <a href="Albuns.php" class="btn btn-primary" target="_blank">Discografia</a>
            </div>
        </div>

        <div class="card" style="width: 18rem;">
            <img src="../Imagens/stk-card-contactos.jpg" class="card-img-top" alt="foto-contactos">
            <div class="card-body">
                <h5 class="card-title">Contactos</h5>
                <p class="card-text">Tens alguma dúvida? Fala comigo.</p>
                <a href="Contactos.php" class="btn btn-primary" target="_blank">Contacta-me</a>
            </div>
        </div>
    </div>
</section>

<footer class="bg-dark text-light py-3 mt-5">
    <div class="container-footer text-center">
        <p>&copy; Sam The Kid | TV Chelas | <a href="#" class="text-light">Política de Privacidade</a></p>
        <div class="mt-3">
            <a href="https://www.tvchelas.com" class="text-light mx-2"><i class="fa-solid fa-globe"></i></a>
            <a href="https://www.facebook.com/SamTheKid" class="text-light mx-2"><i class="fab fa-facebook"></i></a>
            <a href="https://www.instagram.com/mechelas" class="text-light mx-2"><i class="fab fa-instagram"></i></a>
            <a href="https://www.youtube.com/TvChelas" class="text-light mx-2"><i class="fab fa-youtube"></i></a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="../JavaScript/script.js"></script>
</body>
</html>
